import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "Freightr - Drivers",
    description: "",
};

export default function Drivers () {

    return (
        <></>
    )
}