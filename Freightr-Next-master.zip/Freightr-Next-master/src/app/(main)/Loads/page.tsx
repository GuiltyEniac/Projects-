import type { Metadata } from "next";
import LoadsTable from "@/components/Loads/LoadsTable";

export const metadata: Metadata = {
    title: "Freightr - Loads",
    description: "",
};

export default function Loads () {

    return (
        <>
            <LoadsTable className="pt-10"/>
        </>
    )
}