import NavBar from "@/components/Navigation/NavBar";


export default function MainLayout({children}: {children: React.ReactNode}){
    return (
        <>
            <NavBar />
            {children}
        </>
    );
}