import type { Metadata } from "next";

export const metadata: Metadata = {
    title: "Freightr - Reporting",
    description: "",
};


export default function Reporting () {

    return (
        <></>
    )
}