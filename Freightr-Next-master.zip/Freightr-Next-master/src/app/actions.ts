/* eslint-disable @typescript-eslint/no-explicit-any */
"use server"

import { z } from "zod"
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { APIError } from "better-auth/api";


export async function LoginAction(prevState: any, formData: FormData) {

    let validated = false;

    const schema = z.object({
        email: z.string().email(),
        password: z.string()
    });

    const data = schema.safeParse({
        email: formData.get("email"),
        password: formData.get("password")
    });

    if(!data.success){
        const error = JSON.parse(data.error.message);
        const message = error[0].message;

        console.log(message);
        return { message: message};
    }

    try{
        const response = await auth.api.signInEmail({
            body: {
                email: data.data.email,
                password: data.data.password,
            }
        });

        if (response.token){
            validated = true;
        }

    }
    catch(error) {
        if (error instanceof APIError) {
            return { message: error.body.message };
        }
    }

    if(validated) {
        redirect("/");
    }
}

export async function SignUpAction(prevState: any, formData: FormData) {

    const schema = z.object({
        name: z.string(),
        email: z.string().email(),
        password: z.string()
    });

    const data = schema.safeParse({
        name: `${formData.get("firstName")} ${formData.get("lastName")}`,
        email: formData.get("email"),
        password: formData.get("password")
    });

    try{
        const response = await auth.api.signUpEmail({
            body: {
                name: data.data.name,
                email: data.data.email,
                password: data.data.password,
            }
        });

        console.log(response);

    }
    catch(error) {
        if (error instanceof APIError) {
            console.log(error.message, error.status)
        }
    }

}