"use client"
import { SignUpAction } from "@/app/actions";
import Logo from "@/components/Logo/Logo";
import { useActionState } from "react";

export default function Login() {

    const [state, action] = useActionState(SignUpAction, {message: ""});


    return (
        <div className="flex flex-row min-h-screen justify-center items-center">
            <div className="card card-border bg-base-100 w-150 h-150 shadow-md">
                <div className="card-body justify-center items-center">
                    <div className="justify-center items-center">
                        <Logo size={250}/>
                    </div>
                    <form action={action}>

                    { state?.message.includes("User already exists") && (
                        <div className="flex justify-center items-center gap-6 p-6 bg-base-100 rounded border-t-4 border-error">
                            <div className="flex flex-col">
                                <h3 className="font-bold">User already exists!</h3>
                            </div>
                        </div>
                    )}
                        <fieldset className="fieldset flex-col justify-center items-center">
                            <div className="flex justify-center items-center w-95 gap-3">
                                <div className="flex-col">
                                    <label className="fieldset-label">First Name</label>
                                    <input className="input" type="text" placeholder="First Name" name="firstName"/>
                                </div>
                                <div className="flex-col">
                                    <label className="fieldset-label">Last Name</label>
                                    <input className="input" type="text" placeholder="Last Name" name="lastName"/>
                                </div>
                            </div>
                            <div>
                                <label className="fieldset-label">E-Mail</label>
                                <input className="input w-95" type="text" placeholder="E-Mail" name="email"/>
                            </div>
                            <div>
                                <label className="fieldset-label">Password</label>
                                <input className="input w-95" type="password" placeholder="Password" name="password"/>
                            </div>
                            <div>
                                <button className="btn btn-primary mt-4 w-95">Sign Up</button>
                            </div>
                            <p aria-live="polite" className="sr-only" role="status">
                                { state?.message }
                            </p>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    );
}