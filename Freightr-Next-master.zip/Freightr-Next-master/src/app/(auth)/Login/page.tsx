
import Logo from "@/components/Logo/Logo";
import LoginForm from "@/components/Auth/LoginForm";


export default function Login() {

    return (
        <div className="flex flex-row min-h-screen justify-center items-center">
            <div className="card card-border bg-base-100 w-150 h-150 shadow-md">
                <div className="card-body justify-center items-center">

                    <div className="justify-center items-center">
                        <Logo size={250}/>
                    </div>
                    <LoginForm />
                </div>
            </div>
        </div>
    );

}