export default function LoginLayout({children}: {children: React.ReactNode}){

    return (
        <div className="bg-base-200">
            {children}
        </div>
    );

}