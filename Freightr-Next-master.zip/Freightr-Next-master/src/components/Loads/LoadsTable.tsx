function LoadsTableRow ( { loadNum, compName, driverName, date }: { loadNum: number, compName: string, driverName: string, date: string } ) {
    return (
        <tr className="hover:bg-primary">
            <td>{loadNum}</td>
            <td>{compName}</td>
            <td>{driverName}</td>
            <td>{date}</td>
        </tr>
    );
}


export default function LoadsTable ({ className }: {className?: string}) {

    return (
        <div className={className}>
            <div className="h-[80vh] overflow-y-auto justify-center rounded-box border border-base-content/15 bg-base-100 mx-20">
                <table className="table table-pin-rows"> 
                    <thead>
                        <tr className="text-primary border-b-2">
                            <td>Load Number</td>
                            <td>Company Name</td>
                            <td>Driver Name</td>
                            <td>Date</td>
                        </tr>
                    </thead>
                    <tbody>
                        <LoadsTableRow loadNum={0} compName="Dusty Farms" driverName="Jimithy Hall" date="02/12/2024"/>
                        <LoadsTableRow loadNum={0} compName="Dusty Farms" driverName="Jimithy Hall" date="02/12/2024"/>
                        <LoadsTableRow loadNum={0} compName="Dusty Farms" driverName="Jimithy Hall" date="02/12/2024"/>
                        <LoadsTableRow loadNum={0} compName="Dusty Farms" driverName="Jimithy Hall" date="02/12/2024"/>
                        <LoadsTableRow loadNum={0} compName="Dusty Farms" driverName="Jimithy Hall" date="02/12/2024"/>
                        <LoadsTableRow loadNum={0} compName="Dusty Farms" driverName="Jimithy Hall" date="02/12/2024"/>
                    </tbody>
                </table>
            </div>
        </div>
    );

}