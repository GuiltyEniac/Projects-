"use client"
import { LoginAction } from "@/app/actions";
import { useActionState } from "react";
import Alert from "../Alert";


export default function LoginForm () {

    const [state, action, pending] = useActionState(LoginAction, { message: "" });

    return (
        <form action={action}>

            { 
                state?.message === "Invalid email" && (<Alert>Invalid Email!</Alert>)
            }
            { 
                state?.message === "Invalid email or password" && (<Alert>Invalid Login: User Not Found!</Alert>)
            }


            <fieldset className="fieldset flex-col justify-center items-center">
                <div>
                    <label className="fieldset-label">E-Mail</label>
                    <input className="input w-86" type="text" placeholder="E-Mail" name="email"/>
                </div>
                <div>
                    <label className="fieldset-label">Password</label>
                    <input className="input w-86" type="password" placeholder="Password" name="password"/>
                </div>
                <div>
                    <button className="btn btn-primary mt-4 w-86">
                        {
                            pending ? (<span className="loading loading-spinner"></span>) : ("Login")
                        }
                    </button>
                </div>
            </fieldset>
        </form>
    );

}