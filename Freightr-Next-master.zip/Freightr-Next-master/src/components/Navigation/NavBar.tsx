"use client"

import Link from "next/link";
import Logo from "@/components/Logo/Logo";
import { redirect, usePathname } from 'next/navigation'
import { authClient } from "@/lib/auth-client";


const tabs = [
    {name: "Overview", path: "/"},
    {name: "Loads", path: "/Loads"},
    {name: "Companies", path: "/Companies"},
    {name: "Drivers", path: "/Drivers"},
    {name: "Reporting", path: "/Reporting"}
];

async function SignOut() {
    const res = await authClient.signOut({
        fetchOptions: {
            onSuccess: () => {
              redirect("/Login"); // redirect to login page
            },
          },
    });
}

export default function NavBar () {

    const currentPath = usePathname();

    return (
        <div className="px-80 bg-base-300">
            <div className=" navbar items-center justify-center">
                <div className="flex flex-1 justify-start ml-4">
                    <Link href="/" className="text-xl bold">
                        <Logo size={60}/>
                    </Link>
                </div>
                <div className="flex justify-end avatar gap-0 ">
                    <div className="w-10 rounded-full">
                        <img src="https://placehold.co/600x400" alt="avatar"/>
                    </div>
                </div>
                <div className="justify-center items-center ml-5">
                    <button onClick={SignOut} className="btn btn-outline">Log Out</button>
                </div>
            </div>
            <div role="tablist" className="tabs tabs-border">

            {tabs.map((tab) => (

                <Link key={tab.path} href={tab.path} className={`tab tab-lg tab-bordered ${ currentPath === tab.path ? 'tab-active' : '' }`}>
                    {tab.name}
                </Link>

                ))
            }

            </div>
        </div>
    );
}