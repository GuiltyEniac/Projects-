import { NextRequest, NextResponse } from "next/server";
import { getSessionCookie } from "better-auth";
 
export async function middleware(request: NextRequest) {

	console.log("Middleware Hit");

	const sessionCookie = getSessionCookie(request); // Optionally pass config as the second argument if cookie name or prefix is customized.
	if (!sessionCookie) {
		return NextResponse.redirect(new URL("/Login", request.url));
	}
	return NextResponse.next();
}

export const config = {
	matcher: [
	  // Match all routes except login
	  '/((?!Login|SignUp|_next/static|_next/image|favicon.ico).*)',
	]
  }