import { db } from "@/db/drizzle";
import { betterAuth } from "better-auth";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import { nextCookies } from "better-auth/next-js";




export const auth = betterAuth({
    database: drizzleAdapter(db, {
        provider: "sqlite", // or "pg" or "mysql"
    }),
    emailAndPassword: {  
        enabled: true
    },
    asResponse: true,
    baseURL: process.env.BETTER_AUTH_URL,
    plugins: [nextCookies()]
});